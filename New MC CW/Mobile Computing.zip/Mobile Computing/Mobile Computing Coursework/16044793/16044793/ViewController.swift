//
//  ViewController.swift
//  16044793
//
//  Created by Suhail Remtulla on 11/11/2019.
//  Copyright © 2019 Suhail Remtulla. All rights reserved.
//

import UIKit

protocol subviewDelegate{
    func viewBallSpawn()
    
}

class ViewController: UIViewController, subviewDelegate {
    
    var dynamicAnimator: UIDynamicAnimator!
    var gravityBehavior: UIGravityBehavior!
    var dynamicItemBehavior: UIDynamicItemBehavior!
    //var ballView; UIImageView!
    
    @IBOutlet weak var aimView: DragView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        aimView.myDelegate = self
        // Do any additional setup after loading the view.
    }
    
    func viewBallSpawn() {
        let ballView = UIImageView(image: nil)
        ballView.image = UIImage(named: "ball.png")
        ballView.frame = CGRect(x:100, y:100, width: 50, height: 50)
        self.view.addSubview(ballView)
        
        dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
        
        //moving from one point to another
        dynamicItemBehavior = UIDynamicItemBehavior(items: [ballView])
        self.dynamicItemBehavior.addLinearVelocity(CGPoint(x: 60, y:300), for: ballView)
        dynamicAnimator.addBehavior(dynamicItemBehavior)
        
        //adding gravity behaviour
        //gravityBehavior = UIGravityBehavior(items: [ballView])
        //dynamicAnimator.addBehavior(gravityBehavior)
        
        
    }
    
    override open var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return.landscape
    }
}

